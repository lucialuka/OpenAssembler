from openassembler.pyfront import *
@kernel
def positive_overflow(out:Array(i64)):
    count=0
    total=i64(0)
    target=17
    for target in range(2147483646,2147483647,2):
        total+=i64(target)
        count+=1
        if count==8:
            break
    out[0]=total
    out[1]=i64(count)
    out[2]=i64(target)

from openassembler.pyfront import *
@kernel
def negative_overflow(out:Array(i64)):
    count=0
    total=i64(0)
    target=17
    for target in range(-2147483647,-2147483648,-2):
        total+=i64(target)
        count+=1
        if count==8:
            break
    out[0]=total
    out[1]=i64(count)
    out[2]=i64(target)

from openassembler.pyfront import *
@kernel
def large_positive_step(out:Array(i64)):
    count=0
    total=i64(0)
    target=17
    for target in range(-2147483648,2147483647,2147483647):
        total+=i64(target)
        count+=1
        if count==8:
            break
    out[0]=total
    out[1]=i64(count)
    out[2]=i64(target)

from openassembler.pyfront import *
@kernel
def minimum_step(out:Array(i64)):
    count=0
    total=i64(0)
    target=17
    for target in range(2147483647,-2147483648,-2147483648):
        total+=i64(target)
        count+=1
        if count==8:
            break
    out[0]=total
    out[1]=i64(count)
    out[2]=i64(target)

from openassembler.pyfront import *
@kernel
def ordinary(out:Array(i64)):
    count=0
    total=i64(0)
    target=17
    for target in range(0,7,3):
        total+=i64(target)
        count+=1
        if count==8:
            break
    out[0]=total
    out[1]=i64(count)
    out[2]=i64(target)

from openassembler.pyfront import *
@kernel
def empty(out:Array(i64)):
    count=0
    total=i64(0)
    target=17
    for target in range(0,1,-2):
        total+=i64(target)
        count+=1
        if count==8:
            break
    out[0]=total
    out[1]=i64(count)
    out[2]=i64(target)
