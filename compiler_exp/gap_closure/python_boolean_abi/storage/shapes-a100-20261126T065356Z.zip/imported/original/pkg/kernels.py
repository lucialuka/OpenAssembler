from openassembler.pyfront import *
raise RuntimeError("shape discovery must never execute")

@kernel
def rank_one(a:Buffer(bool, 31, strides=(2,), access='read'),out:Array(bool),counter:Array(i32),flag:bool,n:i32):
    i=tid_x()+ctaid_x()*ntid_x()
    if i<n:
        out[i] = a[i] and flag

@kernel
def rank_three(a:Buffer(bool, (2,3,5), strides=(1,2,8), access='read'),out:Buffer(bool, (2,3,5), strides=(31,9,1)),counter:Array(i32),flag:bool,n:i32):
    i=tid_x()+ctaid_x()*ntid_x()
    if i<n:
        row=i//15
        col=(i//5)%3
        last=i%5
        out[row,col,last]=a[row,col,last] or flag

@kernel
def rank_four(a:Buffer(bool, (2,2,3,5), strides=(0,0,5,1), access='read'),out:Buffer(bool, (2,2,3,5)),counter:Array(i32),flag:bool,n:i32):
    i=tid_x()+ctaid_x()*ntid_x()
    if i<n:
        first=i//30
        second=(i//15)%2
        third=(i//5)%3
        last=i%5
        out[first,second,third,last]=not a[first,second,third,last]

@kernel
def read_zero(a:Buffer(bool, (4,7), strides=(11,1), access='read'),out:Array(bool),counter:Array(i32),flag:bool,n:i32):
    i=tid_x()+ctaid_x()*ntid_x()
    if i<n:
        row=i//7-1
        col=i%7
        out[i]=a[row,col] or flag
