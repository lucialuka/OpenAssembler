raise RuntimeError("remote package must not execute")
