#include "settings.cuh"
extern "C" __device__ __noinline__ unsigned helper(unsigned x){return x*MUL+OFFSET;}
