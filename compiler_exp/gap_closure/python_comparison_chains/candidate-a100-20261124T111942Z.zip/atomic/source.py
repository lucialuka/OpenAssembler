from openassembler.pyfront import *
@kernel
def k(a:Array(i32),out:Array(i32),count:Array(i32)):
    i=tid_x()
    value=11
    if -3<a[i]<7:
        value+=1
    if not (0<=a[i]<=3):
        value+=2
    if a[i]<0<atomic_add(count,i,1):
        value+=4
    if -1<atomic_add(count,i,1)<1:
        value+=8
    out[i]=value
