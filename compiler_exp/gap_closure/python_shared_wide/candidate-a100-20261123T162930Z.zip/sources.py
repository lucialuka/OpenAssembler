from openassembler.pyfront import *
@kernel
def i64_exchange(a: Array(i64), out: Array(i64), delta: i64, n: i32):
    shared = shared_array(i64, 128)
    t = tid_x()
    i = ctaid_x() * 128 + t
    shared[t] = a[i]
    syncthreads()
    v = shared[t ^ 64]
    if i < n:
        out[i * 4] = v

@kernel
def i64_literal(a: Array(i64), out: Array(i64), delta: i64, n: i32):
    shared = shared_array(i64, 128)
    t = tid_x()
    i = ctaid_x() * 128 + t
    if t == 127:
        shared[127] = a[i]
    syncthreads()
    v = shared[127]
    if i < n:
        out[i * 4] = v

@kernel
def i64_mixed(a: Array(i64), out: Array(i64), delta: i64, n: i32):
    prefix = shared_array(i32, 1)
    shared = shared_array(i64, 128)
    suffix = shared_array(i32, 3)
    t = tid_x()
    i = ctaid_x() * 128 + t
    if t == 0:
        prefix[0] = 0x12345678
    if t == 0:
        suffix[0] = 0x76543210
        suffix[1] = -1
        suffix[2] = -2147483648
    shared[t] = a[i]
    syncthreads()
    v = shared[t ^ 64]
    if i < n:
        out[i * 4] = v
        out[i * 4 + 1] = i64(prefix[0])
        out[i * 4 + 2] = i64(suffix[0])
        out[i * 4 + 3] = i64(suffix[2])

@kernel
def i64_loop(a: Array(i64), out: Array(i64), delta: i64, n: i32):
    shared = shared_array(i64, 128)
    t = tid_x()
    i = ctaid_x() * 128 + t
    shared[t] = a[i]
    syncthreads()
    v = a[i]
    for step in range(3):
        v = shared[t ^ 64] + delta
        syncthreads()
        shared[t] = v
        syncthreads()
    if i < n:
        out[i * 4] = v

@kernel
def i64_maximum(a: Array(i64), out: Array(i64), delta: i64, n: i32):
    shared = shared_array(i64, 6144)
    t = tid_x()
    i = ctaid_x() * 128 + t
    shared[t + 6016] = a[i]
    syncthreads()
    v = shared[(t ^ 64) + 6016]
    if i < n:
        out[i * 4] = v

@kernel
def i64_padded_maximum(a: Array(i64), out: Array(i64), delta: i64, n: i32):
    prefix = shared_array(i32, 1)
    shared = shared_array(i64, 6143)
    t = tid_x()
    i = ctaid_x() * 128 + t
    if t == 0:
        prefix[0] = 0x12345678
    shared[t + 6015] = a[i]
    syncthreads()
    v = shared[(t ^ 64) + 6015]
    if i < n:
        out[i * 4] = v
        out[i * 4 + 1] = i64(prefix[0])

@kernel
def i64_nested(a: Array(i64), out: Array(i64), delta: i64, n: i32):
    shared = shared_array(i64, 128)
    t = tid_x()
    i = ctaid_x() * 128 + t
    if t < 64:
        if t % 2 == 0:
            shared[t] = a[i] + delta
        else:
            shared[t] = a[i] - delta
    else:
        shared[t] = a[i]
    syncthreads()
    v = shared[t ^ 64]
    if i < n:
        out[i * 4] = v

@kernel
def i64_if_else(a: Array(i64), out: Array(i64), delta: i64, n: i32):
    shared = shared_array(i64, 128)
    t = tid_x()
    i = ctaid_x() * 128 + t
    if t % 2 == 0:
        shared[t] = a[i] + delta
    else:
        shared[t] = a[i] - delta
    syncthreads()
    v = shared[t ^ 64]
    if i < n:
        out[i * 4] = v

@kernel
def i64_phases(a: Array(i64), out: Array(i64), delta: i64, n: i32):
    shared = shared_array(i64, 128)
    t = tid_x()
    i = ctaid_x() * 128 + t
    shared[t] = a[i]
    syncthreads()
    v = shared[t ^ 64]
    syncthreads()
    if t % 2 == 0:
        shared[t] = v + delta
    else:
        shared[t] = v - delta
    syncthreads()
    v = shared[t ^ 64]
    if i < n:
        out[i * 4] = v

@kernel
def i64_legacy32(a: Array(i64), out: Array(i64), delta: i64, n: i32):
    prefix = shared_array(i32, 1)
    shared = shared_array(i32, 128)
    t = tid_x()
    i = ctaid_x() * 128 + t
    if t == 0:
        prefix[0] = 0x12345678
    shared[t] = i32(a[i])
    syncthreads()
    v = i64(shared[t ^ 64])
    if i < n:
        out[i * 4] = v
        out[i * 4 + 1] = i64(prefix[0])

@kernel
def u64_exchange(a: Array(u64), out: Array(u64), delta: u64, n: i32):
    shared = shared_array(u64, 128)
    t = tid_x()
    i = ctaid_x() * 128 + t
    shared[t] = a[i]
    syncthreads()
    v = shared[t ^ 64]
    if i < n:
        out[i * 4] = v

@kernel
def u64_literal(a: Array(u64), out: Array(u64), delta: u64, n: i32):
    shared = shared_array(u64, 128)
    t = tid_x()
    i = ctaid_x() * 128 + t
    if t == 127:
        shared[127] = a[i]
    syncthreads()
    v = shared[127]
    if i < n:
        out[i * 4] = v

@kernel
def u64_mixed(a: Array(u64), out: Array(u64), delta: u64, n: i32):
    prefix = shared_array(i32, 1)
    shared = shared_array(u64, 128)
    suffix = shared_array(i32, 3)
    t = tid_x()
    i = ctaid_x() * 128 + t
    if t == 0:
        prefix[0] = 0x12345678
    if t == 0:
        suffix[0] = 0x76543210
        suffix[1] = -1
        suffix[2] = -2147483648
    shared[t] = a[i]
    syncthreads()
    v = shared[t ^ 64]
    if i < n:
        out[i * 4] = v
        out[i * 4 + 1] = u64(prefix[0])
        out[i * 4 + 2] = u64(suffix[0])
        out[i * 4 + 3] = u64(suffix[2])

@kernel
def u64_loop(a: Array(u64), out: Array(u64), delta: u64, n: i32):
    shared = shared_array(u64, 128)
    t = tid_x()
    i = ctaid_x() * 128 + t
    shared[t] = a[i]
    syncthreads()
    v = a[i]
    for step in range(3):
        v = shared[t ^ 64] + delta
        syncthreads()
        shared[t] = v
        syncthreads()
    if i < n:
        out[i * 4] = v

@kernel
def u64_maximum(a: Array(u64), out: Array(u64), delta: u64, n: i32):
    shared = shared_array(u64, 6144)
    t = tid_x()
    i = ctaid_x() * 128 + t
    shared[t + 6016] = a[i]
    syncthreads()
    v = shared[(t ^ 64) + 6016]
    if i < n:
        out[i * 4] = v

@kernel
def u64_padded_maximum(a: Array(u64), out: Array(u64), delta: u64, n: i32):
    prefix = shared_array(i32, 1)
    shared = shared_array(u64, 6143)
    t = tid_x()
    i = ctaid_x() * 128 + t
    if t == 0:
        prefix[0] = 0x12345678
    shared[t + 6015] = a[i]
    syncthreads()
    v = shared[(t ^ 64) + 6015]
    if i < n:
        out[i * 4] = v
        out[i * 4 + 1] = u64(prefix[0])

@kernel
def u64_nested(a: Array(u64), out: Array(u64), delta: u64, n: i32):
    shared = shared_array(u64, 128)
    t = tid_x()
    i = ctaid_x() * 128 + t
    if t < 64:
        if t % 2 == 0:
            shared[t] = a[i] + delta
        else:
            shared[t] = a[i] - delta
    else:
        shared[t] = a[i]
    syncthreads()
    v = shared[t ^ 64]
    if i < n:
        out[i * 4] = v

@kernel
def u64_if_else(a: Array(u64), out: Array(u64), delta: u64, n: i32):
    shared = shared_array(u64, 128)
    t = tid_x()
    i = ctaid_x() * 128 + t
    if t % 2 == 0:
        shared[t] = a[i] + delta
    else:
        shared[t] = a[i] - delta
    syncthreads()
    v = shared[t ^ 64]
    if i < n:
        out[i * 4] = v

@kernel
def u64_phases(a: Array(u64), out: Array(u64), delta: u64, n: i32):
    shared = shared_array(u64, 128)
    t = tid_x()
    i = ctaid_x() * 128 + t
    shared[t] = a[i]
    syncthreads()
    v = shared[t ^ 64]
    syncthreads()
    if t % 2 == 0:
        shared[t] = v + delta
    else:
        shared[t] = v - delta
    syncthreads()
    v = shared[t ^ 64]
    if i < n:
        out[i * 4] = v

@kernel
def u64_legacy32(a: Array(u64), out: Array(u64), delta: u64, n: i32):
    prefix = shared_array(i32, 1)
    shared = shared_array(u32, 128)
    t = tid_x()
    i = ctaid_x() * 128 + t
    if t == 0:
        prefix[0] = 0x12345678
    shared[t] = u32(a[i])
    syncthreads()
    v = u64(shared[t ^ 64])
    if i < n:
        out[i * 4] = v
        out[i * 4 + 1] = u64(prefix[0])
